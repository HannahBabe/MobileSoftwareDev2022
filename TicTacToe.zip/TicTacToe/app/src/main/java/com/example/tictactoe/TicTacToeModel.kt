package com.example.tictactoe

object TicTacToeModel {

    public val EMPTY: Short = 0
    public val CIRCLE: Short = 1
    public val CROSS: Short = 2

    private val model = arrayOf(
        shortArrayOf(EMPTY, EMPTY, EMPTY),
        shortArrayOf(EMPTY, EMPTY, EMPTY),
        shortArrayOf(EMPTY, EMPTY, EMPTY))

    private var nextPlayer = CIRCLE.toShort()

    fun resetModel() {
        for (i in 0..2) {
            for (j in 0..2) {
                model[i][j] = EMPTY
            }
        }
        nextPlayer = CIRCLE
    }

/*    fun returnWinnerText(): String {
        val whoWonShort = getWinner()
        return when {
            whoWonShort.equals(0) -> {
                "No winner"
            }
            whoWonShort.equals(1) -> {
                "Circle wins!"
            }
            else -> {
                "Cross wins!"
            }
        }

    }*/


    fun getWinner(): Short {
        for (i in 0..2) {
            if (model[i][0] == model[i][1] && model[i][1] == model[i][2]) {
                // check horizontal rows
                return model[i][0]
            }
            if (model[0][i]==model[1][i] && model[1][i]==model[2][i]){
                //check vertical rods
                return model[0][i]
            }
        }
        if (model[0][0]==model[1][1] && model[2][2]==model[1][1]){
            return model[0][0]
        }
        else if (model[0][2]==model[1][1] && model[2][0]==model[1][1]){
            return model[0][2]
        }
        return 0
    }


    fun getFieldContent(x: Int, y: Int) = model[x][y]

    fun setFieldContent(x: Int, y: Int, content: Short) {
        model[x][y] = content
    }

    fun getNextPlayer() = nextPlayer

    fun changeNextPlayer() {
        nextPlayer = if (nextPlayer == CIRCLE) CROSS else CIRCLE
    }
}