package com.example.weatherinfo.adapter

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherinfo.WeatherActivity
import com.example.weatherinfo.data.Item
import com.example.weatherinfo.databinding.ItemRowBinding

class ItemAdapter: RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    var cities = mutableListOf<Item>(
        Item("Paris"),
        Item("London"),
        Item("Budapest")
    )

    companion object {
        const val KEY_DATA = "KEY_DATA"
    }

    val context : Context
    constructor(context: Context) : super() {
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = ItemRowBinding.inflate(
            LayoutInflater.from(context),
            parent, false)
        return ViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = cities[position]
        holder.bind(item)

    }

    fun deleteLastItem() {
        deleteItem(itemCount-1)
    }

    fun deleteItem(idx: Int) {
        cities.removeAt(idx)
        notifyItemRemoved(idx)
    }

    fun addItem(newItem: Item){
        cities.add(newItem)
        notifyItemInserted(cities.lastIndex)
    }

    inner class ViewHolder(var binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Item) {
            binding.tvPlaceName.text = item.placeName

            binding.btnDelete.setOnClickListener {
                deleteItem(this.adapterPosition)
            }

            binding.btnDetails.setOnClickListener{
                var intent = Intent(context, WeatherActivity::class.java)
                intent.putExtra(KEY_DATA, binding.tvPlaceName.text)
                context.startActivity(intent)
            }
        }
    }

    override fun getItemCount(): Int {
        return cities.size
    }
}


class ItemDiffCallback : DiffUtil.ItemCallback<Item>() {
    override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean {
        return oldItem.placeName == newItem.placeName
    }

    @SuppressLint("DiffUtilEquals")
    override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean {
        return oldItem == newItem
    }
}