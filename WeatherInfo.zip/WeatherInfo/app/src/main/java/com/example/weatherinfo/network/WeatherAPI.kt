package com.example.weatherinfo.network
import android.telecom.Call
import retrofit2.http.GET
import retrofit2.http.Query
import com.example.weatherinfo.data.WeatherResult

// https://api.openweathermap.org/data/2.5/weather?q=Budapest,hu&units=metric&appid=22a14251c5e5dc27492593d8c8003e68

//HOST: https://api.openweathermap.org
//PATH: /data/2.5/weather
// ? this is where the query arguments start
//Query Argument: q (CITY), units=metric, appid=22a14251c5e5dc27492593d8c8003e68


interface WeatherAPI {
    @GET("data/2.5/weather")
    fun getWeatherDetails(@Query("q") city: String,
                          @Query("units") units: String,
                          @Query("appid") appid: String): Call
}