package com.example.weatherinfo

import android.os.Bundle
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.ItemTouchHelper
import com.example.weatherinfo.adapter.ItemAdapter
import com.example.weatherinfo.data.Item
import com.example.weatherinfo.databinding.ActivityScrollingBinding
import com.example.weatherinfo.dialog.ItemDialog

class ScrollingActivity : AppCompatActivity(), ItemDialog.ItemHandler {

    private lateinit var binding: ActivityScrollingBinding
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityScrollingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(findViewById(R.id.toolbar))
        binding.toolbarLayout.title = title
        binding.fab.setOnClickListener { view ->
            ItemDialog().show(supportFragmentManager,"ITEM_DIALOG")
        }

        adapter = ItemAdapter(this)
        binding.recyclerItem.adapter=adapter
    }

    override fun itemCreated(item: Item){
        adapter.addItem(item)

        Snackbar.make(binding.root, "Item Created", Snackbar.LENGTH_LONG)
            .setAction("Undo") {
                adapter.deleteLastItem()
            }
            .show()

    }
}