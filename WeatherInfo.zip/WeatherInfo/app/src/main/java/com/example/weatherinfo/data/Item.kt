package com.example.weatherinfo.data

data class Item(
    val placeName: String
    )