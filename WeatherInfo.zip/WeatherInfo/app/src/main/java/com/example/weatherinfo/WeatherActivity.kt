package com.example.weatherinfo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.weatherinfo.adapter.ItemAdapter
import com.example.weatherinfo.adapter.ItemAdapter.Companion.KEY_DATA
import com.example.weatherinfo.data.WeatherResult
import com.example.weatherinfo.databinding.ActivityWeatherBinding
import com.example.weatherinfo.dialog.ItemDialog
import com.example.weatherinfo.network.WeatherAPI
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class WeatherActivity : AppCompatActivity() {

    lateinit var binding: ActivityWeatherBinding
    lateinit var cityName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWeatherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (intent.hasExtra(KEY_DATA)) {
           cityName = intent.getStringExtra(KEY_DATA).toString()
        }
    }

    override fun onResume(){
        super.onResume()

        var retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        var weatherAPI = retrofit.create(WeatherAPI::class.java)
        val call = weatherAPI.getWeatherDetails(cityName,
            "metric",
            "22a14251c5e5dc27492593d8c8003e68"
        )
        call.enqueue(object : Callback<WeatherResult> {
            override fun onResponse(call: Call<WeatherResult>, response: Response<WeatherResult>)
            {
                binding.tvCityName.text = cityName

                binding.tvLat.text = "(${response.body()!!.coord!!.lat}°,"
                binding.tvLong.text = " ${response.body()!!.coord!!.lon}°)"
                binding.tvPressure.text = "Atmospheric pressure: ${response.body()!!.main!!.pressure}hPa"
                binding.tvTemperature.text = "Temperature: ${response.body()!!.main!!.temp}°C"
                binding.tvDescription.text = "${response.body()!!.weather!![0]!!.description}"
                binding.tvWind.text = "Wind speed: ${response.body()!!.wind!!.speed}m/s"
                binding.tvHumidity.text = "Humidity: ${response.body()!!.main!!.humidity}%"


                Glide.with(this@WeatherActivity).load(
                    ("https://openweathermap.org/img/w/" + response.body()?.weather?.get(0)?.icon + ".png"))
                    .into(binding.ivWeatherIcon)
            }
            override fun onFailure(call: Call<WeatherResult>, t: Throwable) {
                binding.tvCityName.text = "Error: ${t.message}"
            }
        })
    }

}