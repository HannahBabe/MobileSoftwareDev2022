package com.example.weatherinfo.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.weatherinfo.data.Item
import com.example.weatherinfo.databinding.ItemDialogBinding

class ItemDialog : DialogFragment() {

    interface ItemHandler{
        fun itemCreated(item: Item)
    }

    lateinit var itemHandler: ItemHandler

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is ItemHandler){
            itemHandler = context
        } else {
            throw RuntimeException(
                "The Activity is not implementing the TodoHandler interface.")
        }
    }
    lateinit var binding: ItemDialogBinding


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())

        binding = ItemDialogBinding.inflate(requireActivity().layoutInflater)
        dialogBuilder.setView(binding.root)

        dialogBuilder.setPositiveButton("OK") { dialog, which ->
            itemHandler.itemCreated(
                Item(binding.etItemName.toString())
            )
        }

        dialogBuilder.setNegativeButton("Cancel") { dialog, which ->
        }

        return dialogBuilder.create()

    }

    override fun onResume() {
        super.onResume()

        val dialog = dialog as AlertDialog
        val positiveButton = dialog.getButton(Dialog.BUTTON_POSITIVE)

        positiveButton.setOnClickListener {
            if (binding.etItemName.text.isEmpty()) {
                binding.etItemName.error = "This field cannot be empty"
            } else {
                handleCreate()

                dialog.dismiss()
            }
        }

    }

    private fun handleCreate() {
        Log.i("item name",binding.etItemName.toString())
            itemHandler.itemCreated(
                Item(
                    binding.etItemName.text.toString()
                )
            )
        }
    }