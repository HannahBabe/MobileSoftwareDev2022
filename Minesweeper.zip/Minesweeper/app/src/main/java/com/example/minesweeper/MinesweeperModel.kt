package com.example.minesweeper

object MinesweeperModel {

    data class Field(
        var type: Int, var minesAround: Int,
        var isFlagged: Boolean, var wasClicked: Boolean
    )

    private val fieldMatrix: Array<Array<Field>> = arrayOf(
        arrayOf(
            Field(1, 0, isFlagged = false, wasClicked = false),
            Field(0, 1, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false)
        ),
        arrayOf(
            Field(0, 2, isFlagged = false, wasClicked = false),
            Field(0, 3, isFlagged = false, wasClicked = false),
            Field(0, 2, isFlagged = false, wasClicked = false),
            Field(0, 1, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false)
        ),
        arrayOf(
            Field(0, 1, isFlagged = false, wasClicked = false),
            Field(1, 0, isFlagged = false, wasClicked = false),
            Field(1, 0, isFlagged = false, wasClicked = false),
            Field(0, 1, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false)
        ),
        arrayOf(
            Field(0, 1, isFlagged = false, wasClicked = false),
            Field(0, 2, isFlagged = false, wasClicked = false),
            Field(0, 2, isFlagged = false, wasClicked = false),
            Field(0, 2, isFlagged = false, wasClicked = false),
            Field(0, 1, isFlagged = false, wasClicked = false)
        ),
        arrayOf(
            Field(0, 0, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false),
            Field(0, 0, isFlagged = false, wasClicked = false),
            Field(0, 1, isFlagged = false, wasClicked = false),
            Field(1, 0, isFlagged = false, wasClicked = false)
        )
    )

    fun resetModel() {
        for (i in 0..4) {
            for (j in 0..4) {
                fieldMatrix[i][j].isFlagged = false
                fieldMatrix[i][j].wasClicked = false
            }
        }
    }

    fun showBombs(){
        for (i in 0..4) {
            for (j in 0..4) {
                if (fieldMatrix[i][j].type == 1)
                    fieldMatrix[i][j].wasClicked = true
            }
        }
    }



    fun getFieldContent(x: Int, y: Int) = fieldMatrix[x][y]

    fun isFinished(): Boolean {
        for (i in 0..4) {
            for (j in 0..4) {
                if ((fieldMatrix[i][j].type == 0 && !fieldMatrix[i][j].wasClicked) || (fieldMatrix[i][j].type == 1 && !fieldMatrix[i][j].isFlagged)) {
                    return false
                }
            }
        }
        return true
    }

}