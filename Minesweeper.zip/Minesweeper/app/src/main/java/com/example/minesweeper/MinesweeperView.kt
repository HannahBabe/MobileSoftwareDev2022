package com.example.minesweeper

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.ToggleButton

class MinesweeperView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {

    private var paintBackground: Paint = Paint()
    private var paintLine: Paint = Paint()
    private var paint1: Paint = Paint()
    private var paint2: Paint = Paint()
    private var paint3: Paint = Paint()
    private var DIMENSION: Short = 5


    private var bitmapTile: Bitmap =
        BitmapFactory.decodeResource(resources, R.drawable.tile)

    private var bitmapFlag: Bitmap =
        BitmapFactory.decodeResource(resources, R.drawable.flag)

    private var bitmapMine: Bitmap =
        BitmapFactory.decodeResource(resources, R.drawable.mine)

    init {
        paintBackground.color = Color.DKGRAY
        paintBackground.style = Paint.Style.FILL

        paintLine.color = Color.WHITE
        paintLine.style = Paint.Style.STROKE
        paintLine.strokeWidth = 5f

        paint1.color = Color.BLUE
        paint1.textSize = 90f
        paint1.typeface = Typeface.DEFAULT_BOLD

        paint2.color = Color.GREEN
        paint2.textSize = 90f
        paint2.typeface = Typeface.DEFAULT_BOLD

        paint3.color = Color.RED
        paint3.textSize = 90f
        paint3.typeface = Typeface.DEFAULT_BOLD

    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        bitmapTile = Bitmap.createScaledBitmap(
            bitmapTile,
            width / DIMENSION, height / DIMENSION, false
        )
        bitmapFlag = Bitmap.createScaledBitmap(
            bitmapFlag,
            width / DIMENSION, height / DIMENSION, false
        )

        bitmapMine = Bitmap.createScaledBitmap(
            bitmapMine,
            width / DIMENSION, height / DIMENSION, false
        )

    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        canvas?.drawRect(
            0f, 0f, width.toFloat(),
            height.toFloat(), paintBackground
        )

        // canvas?.drawBitmap(bitmapBg, 0f, 0f, null)


        drawGameArea(canvas!!)

        drawPlayers(canvas!!)

    }

    private fun drawGameArea(canvas: Canvas) {
        // border
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintLine)
        // four horizontal lines
        canvas.drawLine(
            0f, (height / DIMENSION).toFloat(), width.toFloat(), (height / DIMENSION).toFloat(),
            paintLine
        )
        canvas.drawLine(
            0f,
            (2 * height / DIMENSION).toFloat(),
            width.toFloat(),
            (2 * height / DIMENSION).toFloat(),
            paintLine
        )
        canvas.drawLine(
            0f,
            (3 * height / DIMENSION).toFloat(),
            width.toFloat(),
            (3 * height / DIMENSION).toFloat(),
            paintLine
        )
        canvas.drawLine(
            0f,
            (4 * height / DIMENSION).toFloat(),
            width.toFloat(),
            (4 * height / DIMENSION).toFloat(),
            paintLine
        )


        // four vertical lines
        canvas.drawLine(
            (width / DIMENSION).toFloat(), 0f, (width / DIMENSION).toFloat(), height.toFloat(),
            paintLine
        )
        canvas.drawLine(
            (2 * width / DIMENSION).toFloat(),
            0f,
            (2 * width / DIMENSION).toFloat(),
            height.toFloat(),
            paintLine
        )
        canvas.drawLine(
            (3 * width / DIMENSION).toFloat(),
            0f,
            (3 * width / DIMENSION).toFloat(),
            height.toFloat(),
            paintLine
        )
        canvas.drawLine(
            (4 * width / DIMENSION).toFloat(),
            0f,
            (4 * width / DIMENSION).toFloat(),
            height.toFloat(),
            paintLine
        )
    }

    private fun drawPlayers(canvas: Canvas) {
        for (i in 0..4) {
            for (j in 0..4) {
                //set tile to field content at (i,j)
                val tile = MinesweeperModel.getFieldContent(i, j)

                //if not clicked, draw tile
                if (!tile.wasClicked) {
                    canvas.drawBitmap(
                        bitmapTile,
                        (i * width / DIMENSION).toFloat(),
                        (j * height / DIMENSION).toFloat(),
                        null
                    )
                    //if flagged, draw flag
                    if (tile.isFlagged) {
                        canvas.drawBitmap(
                            bitmapFlag,
                            (i * width / DIMENSION).toFloat(),
                            (j * height / DIMENSION).toFloat(),
                            null
                        )
                    }
                } else {
                    //if mine
                    when (tile.type) {
                        1 -> canvas.drawBitmap(
                            bitmapMine,
                            (i * width / DIMENSION).toFloat(),
                            (j * height / DIMENSION).toFloat(),
                            null
                        )
                    }
                    //mines around
                    when (tile.minesAround) {
                        1 -> canvas?.drawText(
                            "1", ((i * width / DIMENSION) + (0.3 * width / DIMENSION)).toFloat(),
                            ((j * height / DIMENSION) + (0.7 * width / DIMENSION)).toFloat(), paint1
                        )
                        2 -> canvas?.drawText(
                            "2", ((i * width / DIMENSION) + (0.3 * width / DIMENSION)).toFloat(),
                            ((j * height / DIMENSION) + (0.7 * width / DIMENSION)).toFloat(), paint2
                        )
                        3 -> canvas?.drawText(
                            "3", ((i * width / DIMENSION) + (0.3 * width / DIMENSION)).toFloat(),
                            ((j * height / DIMENSION) + (0.7 * width / DIMENSION)).toFloat(), paint3
                        )
                    }

                }

            }
        }
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_DOWN) {
            val tX = event.x.toInt() / (width / DIMENSION)
            val tY = event.y.toInt() / (height / DIMENSION)

            if (tX < DIMENSION && tY < DIMENSION && !MinesweeperModel.getFieldContent(
                    tX,
                    tY
                ).wasClicked && !(context as MainActivity).getToggleVal()
            ) {
                MinesweeperModel.getFieldContent(tX, tY).wasClicked = true
                invalidate()
            } else if (tX < DIMENSION && tY < DIMENSION && !MinesweeperModel.getFieldContent(
                    tX,
                    tY
                ).wasClicked && (context as MainActivity).getToggleVal()
            ) {
                MinesweeperModel.getFieldContent(tX, tY).isFlagged =
                    !MinesweeperModel.getFieldContent(tX, tY).isFlagged
                invalidate()

            }
            if ((tX < DIMENSION && tY < DIMENSION && MinesweeperModel.getFieldContent(
                    tX,
                    tY
                ).type == 0 && (context as MainActivity).getToggleVal()) ||
                (tX < DIMENSION && tY < DIMENSION && MinesweeperModel.getFieldContent(
                    tX,
                    tY
                ).type == 1 && !(context as MainActivity).getToggleVal())
            ) {
                MinesweeperModel.showBombs()
                (context as MainActivity).showLoseText()
            }
        }
        if (MinesweeperModel.isFinished()) {
            (context as MainActivity).showWinText()
        }

        invalidate()

        return true
    }

    fun resetGame() {
        MinesweeperModel.resetModel()
        invalidate()
    }

}