package com.example.minesweeper

import android.os.Bundle
import android.widget.Button
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity
import com.example.minesweeper.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import kotlin.properties.Delegates

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.resetBtn.setOnClickListener {
            binding.minesweeperView.resetGame()
        }
    }

    public fun getToggleVal(): Boolean {
        return binding.toggleFlag.isChecked
    }

    fun showWinText() {
        val snackWin = Snackbar.make(binding.root, getString(R.string.winText), Snackbar.LENGTH_LONG)
            .setAction(getString(R.string.resetText)){
                binding.minesweeperView.resetGame()
            }
        snackWin.show()

    }

    fun showLoseText() {
        val snackLose = Snackbar.make(binding.root, getString(R.string.loseText), Snackbar.LENGTH_LONG)
            .setAction(getString(R.string.resetText)){
                binding.minesweeperView.resetGame()
            }
        snackLose.show()

    }
}