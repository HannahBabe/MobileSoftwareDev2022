package com.example.frisbeefinder.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.frisbeefinder.ForumActivity
import com.example.frisbeefinder.R
import com.example.frisbeefinder.data.Post
import com.example.frisbeefinder.databinding.PostRowBinding
import com.example.frisbeefinder.dialog.PostDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class PostsAdapter : RecyclerView.Adapter<PostsAdapter.ViewHolder> {

    lateinit var context: Context
    var  postsList = mutableListOf<Post>()
    var  postKeys = mutableListOf<String>()

    lateinit var currentUid: String

    constructor(context: Context, uid: String) : super() {
        this.context = context
        this.currentUid = uid
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = PostRowBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return postsList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var post = postsList.get(holder.adapterPosition)

        holder.tvTitle.text = post.title
        holder.tvAuthor.text = post.author
        holder.tvDescription.text = post.description
        holder.tvLocation.text = post.location
        holder.tvDate.text = post.date
        holder.tvTime.text = post.time
       // holder.btnInterested.text = "Interested"
        Log.i("TAG",post.interested.toString())

        if (currentUid == post.uid) {
            holder.btnDelete.visibility = View.VISIBLE
            holder.btnEdit.visibility = View.VISIBLE
        } else {
            holder.btnDelete.visibility = View.GONE
            holder.btnEdit.visibility = View.GONE
        }

        holder.btnDelete.setOnClickListener {
            removePost(holder.adapterPosition)
        }

        holder.btnEdit.setOnClickListener{
            (context as ForumActivity).showEditDialog(post)
        }

        holder.btnInterested.setOnClickListener{
            if (currentUid in post.interested){//doesnt work
                Toast.makeText(context, "Got here", Toast.LENGTH_LONG)
                holder.btnInterested.setBackgroundColor(holder.btnInterested.getContext().getResources().getColor(R.color.red_500))
                removeInterested(holder.adapterPosition)
            }
            holder.btnInterested.setBackgroundColor(holder.btnInterested.getContext().getResources().getColor(R.color.peach))
            addInterested(holder.adapterPosition)
        }
    }

    fun addInterested(index: Int){
        FirebaseFirestore.getInstance().collection(
            PostDialog.POSTS_COLLECTION).document(
            postKeys[index]
        ).update("interested", FieldValue.arrayUnion(FirebaseAuth.getInstance().currentUser!!.uid))
    }

    fun removeInterested(index: Int){
        FirebaseFirestore.getInstance().collection(
            PostDialog.POSTS_COLLECTION).document(
            postKeys[index]
        ).update("interested", FieldValue.arrayRemove(FirebaseAuth.getInstance().currentUser!!.uid))
    }

    fun addPost(post: Post, key: String) {
        postsList.add(post)
        postKeys.add(key)
        //notifyDataSetChanged()
        notifyItemInserted(postsList.lastIndex)
    }

    // when I remove the post object
    private fun removePost(index: Int) {
        FirebaseFirestore.getInstance().collection(
            PostDialog.POSTS_COLLECTION).document(
            postKeys[index]
        ).delete()

        postsList.removeAt(index)
        postKeys.removeAt(index)
        notifyItemRemoved(index)
    }

    // when somebody else removes an object
    fun removePostByKey(key: String) {
        val index = postKeys.indexOf(key)
        if (index != -1) {
            postsList.removeAt(index)
            postKeys.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    inner class ViewHolder(val binding: PostRowBinding) : RecyclerView.ViewHolder(binding.root){
        var tvAuthor = binding.tvAuthor
        var tvTitle = binding.tvTitle
        var tvDescription = binding.tvDescription
        var btnDelete = binding.btnDelete
        var tvLocation  = binding.tvLocation
        var tvDate = binding.tvDate
        var tvTime = binding.tvTime
        var btnEdit = binding.btnEdit
        var btnInterested = binding.btnInterested
    }
}