package com.example.frisbeefinder.data

import java.io.Serializable

data class Post(
    var uid: String = "",
    var author: String = "",
    var title: String = "",
    var description: String = "",
    var date: String = "",
    var time: String = "",
    var location: String = "",
    var interested: List<String> = ArrayList()
) : Serializable
