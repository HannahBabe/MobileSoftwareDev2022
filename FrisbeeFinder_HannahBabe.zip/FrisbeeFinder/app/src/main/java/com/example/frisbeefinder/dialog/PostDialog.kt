package com.example.frisbeefinder.dialog

import android.app.Dialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.frisbeefinder.ForumActivity
import com.example.frisbeefinder.R
import com.example.frisbeefinder.data.Post
import com.example.frisbeefinder.databinding.PostDialogBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class PostDialog : DialogFragment() {

    companion object {
        const val POSTS_COLLECTION = "posts"
    }


    lateinit var binding: PostDialogBinding

    private var isEditMode = false

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())

        //are we in edit mode?  - have we received a Post object to edit?
        if (arguments != null && requireArguments().containsKey(
                ForumActivity.KEY_POST_EDIT)) {
            isEditMode = true
            dialogBuilder.setTitle(getString(R.string.edit_post))
        } else {
            isEditMode = false
            dialogBuilder.setTitle(getString(R.string.new_post))
        }

        binding = PostDialogBinding.inflate(requireActivity().layoutInflater)
        dialogBuilder.setView(binding.root)

        //pre-fill the dialog if we are in edit mode
        if (isEditMode) {
            val postToEdit =
                requireArguments().getSerializable(
                    ForumActivity.KEY_POST_EDIT) as Post

            binding.etTitle.setText(postToEdit.title)
            binding.etDescription.setText(postToEdit.description)
            binding.etDate.setText(postToEdit.date)
            binding.etTime.setText(postToEdit.time)
            binding.etPostalAddress.setText(postToEdit.location)
        }

        dialogBuilder.setPositiveButton(getString(R.string.ok)) { dialog, which ->
        }

        dialogBuilder.setNegativeButton(getString(R.string.cancel)) { dialog, which ->
        }

        return dialogBuilder.create()
    }

    override fun onResume() {
        super.onResume()

        val dialog = dialog as AlertDialog
        val positiveButton = dialog.getButton(Dialog.BUTTON_POSITIVE)

        positiveButton.setOnClickListener {
            if (binding.etTitle.text.toString()=="") {
                binding.etTitle.error = getString(R.string.this_field_cannot_be_empty)
            }else if (binding.etPostalAddress.text.toString()=="") {
                binding.etPostalAddress.error = getString(R.string.this_field_cannot_be_empty)
            }else if (binding.etDate.text.toString()==""){
                binding.etDate.error = getString(R.string.this_field_cannot_be_empty)
            }else if (binding.etTime.text.toString()==""){
                binding.etTime.error = getString(R.string.this_field_cannot_be_empty)
            } else {
                if (isEditMode) {
                    handleEdit()
                } else {
                    uploadPost()
                }


            }
        }

    }

    private fun uploadPost() {
        val newPost = Post(
            FirebaseAuth.getInstance().currentUser!!.uid,
            FirebaseAuth.getInstance().currentUser!!.email!!,
            binding.etTitle.text.toString(),
            binding.etDescription.text.toString(),
            binding.etDate.text.toString(),
            binding.etTime.text.toString(),
            binding.etPostalAddress.text.toString(),
        )

        // "connect" to posts collection (table)
        val postsCollection =
            FirebaseFirestore.getInstance().collection(POSTS_COLLECTION)
        postsCollection.add(newPost)
            .addOnSuccessListener {
                Toast.makeText(context,
                    getString(R.string.post_saved), Toast.LENGTH_LONG).show()
                dialog!!.dismiss()
                //finish()
            }
            .addOnFailureListener {
                Toast.makeText(context,
                    "Error ${it.message}", Toast.LENGTH_LONG).show()
                dialog!!.dismiss()
            }
    }

    private fun handleEdit() {
        val postToEdit =
            (requireArguments().getSerializable(
                ForumActivity.KEY_POST_EDIT
            ) as Post).copy( //Need to make a copy of the item in order for the recycler view to recognize that a change was made.
                title = binding.etTitle.text.toString(),
                description = binding.etDescription.text.toString(),
                date = binding.etDate.text.toString(),
                time = binding.etTime.text.toString(),
                location = binding.etPostalAddress.text.toString()
            )

        //add firebase update here
        dialog!!.dismiss()

    }

}