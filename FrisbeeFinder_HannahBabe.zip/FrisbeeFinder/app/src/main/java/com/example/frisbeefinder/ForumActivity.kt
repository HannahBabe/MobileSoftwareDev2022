package com.example.frisbeefinder

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import com.example.frisbeefinder.adapter.PostsAdapter
import com.example.frisbeefinder.data.Post
import com.example.frisbeefinder.databinding.ActivityForumBinding
import com.example.frisbeefinder.dialog.PostDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetPrompt


class ForumActivity : AppCompatActivity() {

    companion object {
        const val KEY_POST_EDIT = "KEY_POST_EDIT"
        const val POST_DIALOG = "POST_DIALOG"
        const val PREFNAME = "MYPREFERENCES"
        const val KEY_WAS_STARTED = "KEY_WAS_STARTED"
    }

    private lateinit var binding: ActivityForumBinding
    private lateinit var postsAdapter: PostsAdapter

    private var listenerReg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityForumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(findViewById(R.id.toolbar))
        binding.toolbarLayout.title = title


        binding.fabAdd.setOnClickListener { view ->
            PostDialog().show(supportFragmentManager, POST_DIALOG)
        }

        postsAdapter = PostsAdapter(this,
            FirebaseAuth.getInstance().currentUser!!.uid)
        binding.recyclerPosts.adapter = postsAdapter

        initFirebaseQuery()

        if(!wasStartedBefore()) {
            MaterialTapTargetPrompt.Builder(this)
                .setTarget(binding.fabAdd)
                .setPrimaryText(getString(R.string.new_event_post))
                .setSecondaryText(getString(R.string.click_here_new_event))
                .show()
            saveAppWasStarted()
        }

    }

    private fun saveAppWasStarted() {
        val sharedpref = getSharedPreferences(PREFNAME,
            MODE_PRIVATE)
        val editor = sharedpref.edit()
        editor.putBoolean(KEY_WAS_STARTED, true)
        editor.apply()
    }

    private fun wasStartedBefore() : Boolean {
        val sharedPref = getSharedPreferences(PREFNAME, MODE_PRIVATE)
        return sharedPref.getBoolean(KEY_WAS_STARTED, false)
    }

    fun showEditDialog(postToEdit: Post){
        val dialog = PostDialog()

        val bundle = Bundle()
        bundle.putSerializable(KEY_POST_EDIT, postToEdit)
        dialog.arguments = bundle
        dialog.show(supportFragmentManager, "TAG_POST_EDIT")
    }

    private fun initFirebaseQuery() {
        val queryRef =
            FirebaseFirestore.getInstance().collection(
                PostDialog.POSTS_COLLECTION)

        val eventListener = object : EventListener<QuerySnapshot> {
            override fun onEvent(querySnapshot: QuerySnapshot?, e: FirebaseFirestoreException?) {
                if (e != null) {
                    Toast.makeText(
                        this@ForumActivity, "Error: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }

                for (docChange in querySnapshot?.documentChanges!!) {
                    when (docChange.type) {
                        DocumentChange.Type.ADDED -> {
                            val post = docChange.document.toObject(Post::class.java)
                            postsAdapter.addPost(post, docChange.document.id)

                            val subCollRef =
                                FirebaseFirestore.getInstance().collection(
                                    PostDialog.POSTS_COLLECTION).document(docChange.document.id).
                                    collection("interested")


                        }
                        DocumentChange.Type.REMOVED -> {
                            postsAdapter.removePostByKey(docChange.document.id)
                        }
                        DocumentChange.Type.MODIFIED -> {

                        }
                    }
                }

            }
        }

        listenerReg = queryRef.addSnapshotListener(eventListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        listenerReg?.remove()
    }


}