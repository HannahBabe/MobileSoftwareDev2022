package com.example.frisbeefinder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.frisbeefinder.data.Post
import com.example.frisbeefinder.databinding.ActivityMapsBinding
import com.example.frisbeefinder.dialog.PostDialog
import com.example.frisbeefinder.dialog.PostDialog.Companion.POSTS_COLLECTION
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.firestore.*
import com.google.firebase.firestore.EventListener
import java.io.IOException
import java.util.*


class MapsActivity : AppCompatActivity(), OnMapReadyCallback,
    LocationManager.OnNewLocationAvailable{

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    private lateinit var myLocationManager: LocationManager

    private var listenerReg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        myLocationManager = LocationManager(this, this)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.fabForum.setOnClickListener{ view ->
            startActivity(Intent(this, ForumActivity::class.java))
        }

        requestNeededPermission()


    }


    fun requestNeededPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
        } else {
            // we have the permission
            myLocationManager.startLocationMonitoring()

        }
    }

    override fun onResume() {
        super.onResume()

        val queryRef =
            FirebaseFirestore.getInstance().collection(
                PostDialog.POSTS_COLLECTION)

        val eventListener = object : EventListener<QuerySnapshot> {
            override fun onEvent(querySnapshot: QuerySnapshot?, e: FirebaseFirestoreException?) {
                if (e != null) {
                    Toast.makeText(
                        this@MapsActivity, "Error: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
                if (querySnapshot?.documentChanges!!.isNotEmpty()){
                    mMap.clear()
                }
                for (docChange in querySnapshot?.documentChanges!!) {
                    when (docChange.type) {
                        DocumentChange.Type.ADDED  -> {
                            val post = docChange.document.toObject(Post::class.java)
                            var numInterested = (post.interested).size
                            var interestedText = getString(R.string.people_interested)
                            if (numInterested==1){
                                interestedText = getString(R.string.person_interested)
                            }

                            var latLng= getLocationFromAddress(post.location)
                            mMap.addMarker(
                                MarkerOptions().position(LatLng(latLng!!.latitude, latLng!!.longitude))
                                    .title(post.title)
                                    .snippet("$numInterested $interestedText")
                                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
                                    .alpha(0.8f)
                            )
                        }
                        DocumentChange.Type.REMOVED -> {
                        }
                        DocumentChange.Type.MODIFIED -> {
                            val post = docChange.document.toObject(Post::class.java)
                            var numInterested = (post.interested).size
                            var interestedText = getString(R.string.people_interested)
                            if (numInterested==1){
                                interestedText = getString(R.string.person_interested)
                            }

                            var latLng= getLocationFromAddress(post.location)
                            mMap.addMarker(
                                MarkerOptions().position(LatLng(latLng!!.latitude, latLng!!.longitude))
                                    .title(post.title)
                                    .snippet("$numInterested $interestedText")
                                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
                                    .alpha(0.8f)
                            )
                        }
                        }
                    }
                }

            }
        listenerReg = queryRef.addSnapshotListener(eventListener)

        }

    override fun onDestroy() {
        super.onDestroy()
        listenerReg?.remove()
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        FirebaseFirestore.getInstance().collection(POSTS_COLLECTION).get()
            .addOnSuccessListener { result ->
            for (document in result) {
                var numInterested = (document.data["interested"] as List<String>).size
                var interestedText = getString(R.string.people_interested)
                if (numInterested==1){
                    interestedText = getString(R.string.person_interested)
                }

                var latLng= getLocationFromAddress(document.data["location"] as String?)
                Log.d("LOCATION", "${document.id} => ${document.data["location"]}")
                mMap.addMarker(
                    MarkerOptions().position(LatLng(latLng!!.latitude, latLng!!.longitude))
                        .title(document.data["title"] as String?)
                        .snippet("$numInterested $interestedText")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
                        .alpha(0.8f)
                )
                Log.d("TAG", "${document.id} => ${document.data}")
            }
        }
                .addOnFailureListener { exception ->
                    Log.d("TAG", "Error getting documents: ", exception)
                }


        val budapest = LatLng(47.4979, 19.0402)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom((budapest), 12F))

    }

    override fun onNewLocation(location: Location) {
    }

    fun getLocationFromAddress(strAddress: String?): GeoPoint? {
        val coder = Geocoder(this)
        val address: List<Address>?
        var p1: GeoPoint? = null
        try {
            address = coder.getFromLocationName(strAddress, 5)
            Log.d("GeoCoder1", "${address}")
            if (address == null) {
                return null
            }
            Log.d("GeoCoder", "${address}")
            val location = address[0]
            p1 = GeoPoint(
                (location.latitude),
                (location.longitude)
            )
            return p1
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return GeoPoint(47.4979, 19.0402)
    }

}