package com.example.andwallet

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.andwallet.databinding.ActivityMainBinding
import com.example.andwallet.databinding.MoneyRowBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var income : Int =0
    private var expenses : Int = 0

    companion object {
        const val KEY_INCOME = "KEY_INCOME"
        const val KEY_EXPENSE= "KEY_EXP"
        const val KEY_BALANCE = "KEY_BALANCE"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSave.setOnClickListener {
            addNewMoneyItem()
        }

        binding.btnSummary.setOnClickListener {
            val intentSummary = Intent()
            intentSummary.setClass(this,
                SummaryActivity::class.java)

            intentSummary.putExtra(
                KEY_EXPENSE,
                expenses.toString())

            intentSummary.putExtra(
                    KEY_INCOME,
            income.toString())

            intentSummary.putExtra(
                KEY_BALANCE,
                (income-expenses).toString())

            startActivity(intentSummary)
        }
    }

    private fun addNewMoneyItem() {
        val moneyRow = MoneyRowBinding.inflate(layoutInflater)
        try {
            if (checkInputFields()) {
                moneyRow.tvMoneyTitle.text = binding.tvDescription.text.toString()
                moneyRow.tvMoneyAmount.text = "${binding.tvAmount.text.toString().toInt()}"

                moneyRow.btnDelete.setOnClickListener {
                    binding.layoutContent.removeView(moneyRow.root)
                }

                if (binding.toggleButton.isChecked) {
                    moneyRow.ivIcon.setImageResource(R.drawable.income)
                    income += binding.tvAmount.text.toString().toInt()
                } else {
                    moneyRow.ivIcon.setImageResource(R.drawable.expense)
                    expenses += binding.tvAmount.text.toString().toInt()
                }


                binding.layoutContent.addView(moneyRow.root)
            }
        }
        catch (e: Exception){
            Log.e("ERROR","Error: ${e.message}")
            }
    }

    fun checkInputFields(): Boolean {
        if (binding.tvDescription.text.isEmpty()) {
            binding.tvDescription.error = getString(R.string.empty_field)
            return false
        }
        if (binding.tvAmount.text.isEmpty()) {
            binding.tvAmount.error = getString(R.string.empty_field)
            return false
        }

        return true
    }
}