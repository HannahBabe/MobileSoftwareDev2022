package com.example.andwallet

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.andwallet.databinding.ActivitySummaryBinding

class SummaryActivity : AppCompatActivity() {
    lateinit var binding: ActivitySummaryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySummaryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (intent.hasExtra(MainActivity.KEY_INCOME)) {
            binding.tvIncome.text = intent.getStringExtra(MainActivity.KEY_INCOME)
            binding.tvExpenses.text = intent.getStringExtra(MainActivity.KEY_EXPENSE)
            binding.tvBalance.text = intent.getStringExtra(MainActivity.KEY_BALANCE)
        }
    }
}