package com.example.andwallet

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.andwallet.databinding.ActivityPinBinding

class PINActivity : AppCompatActivity() {
    lateinit var binding: ActivityPinBinding

    val key: Int = 5738

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnEnter.setOnClickListener {
            if (binding.editTextTextPassword.text.isEmpty()){
                binding.editTextTextPassword.error = getString(R.string.empty_field)
            } else if (binding.editTextTextPassword.text.toString().toInt() != key){
                binding.editTextTextPassword.error = getString(R.string.wrong_password)
            } else{
                val intentDetails = Intent()
                intentDetails.setClass(
                    this,
                    MainActivity::class.java
                )

                startActivity(intentDetails)
            }
        }


    }
}