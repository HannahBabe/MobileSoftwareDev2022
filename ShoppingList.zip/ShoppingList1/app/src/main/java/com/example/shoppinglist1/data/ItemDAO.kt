package com.example.shoppinglist1.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ItemDAO {

    @Query("SELECT * FROM itemtable")
    fun getAllItems() : LiveData<List<Item>>

    @Query("SELECT itemPrice FROM itemtable")
    fun getAllPrices() : List<String>

    @Insert
    fun insertItem(item: Item)

    @Delete
    fun deleteItem(item: Item)

    @Update
    fun updateItem(item: Item)

    @Query("DELETE FROM [itemtable]")
    fun deleteAll()

}