package com.example.shoppinglist1.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.shoppinglist1.R
import com.example.shoppinglist1.ScrollingActivity
import com.example.shoppinglist1.data.AppDatabase
import com.example.shoppinglist1.data.Item
import com.example.shoppinglist1.databinding.ItemRowBinding
import com.example.shoppinglist1.touch.ItemTouchHelperCallback
import kotlin.concurrent.thread

class ItemAdapter(var context: Context)
    : ListAdapter<Item, ItemAdapter.ViewHolder>(ItemDiffCallback()),
    ItemTouchHelperCallback {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemBinding = ItemRowBinding.inflate(
            LayoutInflater.from(context),
            parent, false)
        return ViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)

    }

    fun deleteLastItem() {
        //todoItems.removeLast()
        //notifyItemRemoved(todoItems.lastIndex+1)
        deleteItem(itemCount-1)
    }

    fun deleteItem(idx: Int) {
        thread{
            AppDatabase.getInstance(context).itemDao().deleteItem(getItem(idx))
        }
    }

    override fun onDismissed(position: Int) {
        deleteItem(position)
    }

    override fun onItemMoved(fromPosition: Int, toPosition: Int) {
        notifyItemMoved(fromPosition, toPosition)
    }

    inner class ViewHolder(var binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Item) {
            binding.tvItemName.text = item.itemName
            binding.tvItemPrice.text = item.itemPrice
            binding.cbPurchased.isChecked = item.isBought

            when (item.itemCategory) {
                0 -> {
                    binding.icon.setImageResource(R.drawable.fruit)
                }
                1 -> {
                    binding.icon.setImageResource(R.drawable.vegetable)
                }
                2 -> {
                    binding.icon.setImageResource(R.drawable.electronics)
                }
                3 -> {
                    binding.icon.setImageResource(R.drawable.academics)
                }
                4-> {
                    binding.icon.setImageResource(R.drawable.life)
                }
            }

            binding.btnDelete.setOnClickListener {
                deleteItem(this.adapterPosition)
            }

            binding.btnEdit.setOnClickListener{
                (context as ScrollingActivity).showEditDialog(
                    getItem(this.adapterPosition)
                )
            }

            binding.cbPurchased.setOnClickListener {
                val currentItem = getItem(adapterPosition)
                currentItem.isBought = binding.cbPurchased.isChecked
                thread {
                    AppDatabase.getInstance(context).itemDao().updateItem(currentItem)
                }
            }
        }

    }
}


class ItemDiffCallback : DiffUtil.ItemCallback<Item>() {
    override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean {
        return oldItem.itemid == newItem.itemid
    }

    @SuppressLint("DiffUtilEquals")
    override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean {
        return oldItem == newItem
    }
}
