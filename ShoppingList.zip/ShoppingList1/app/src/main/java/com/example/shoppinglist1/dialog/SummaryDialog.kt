package com.example.shoppinglist1.dialog

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.shoppinglist1.databinding.ItemDialogBinding
import com.example.shoppinglist1.databinding.SummaryDialogBinding

class SummaryDialog : DialogFragment() {
    lateinit var binding: SummaryDialogBinding

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        binding = SummaryDialogBinding.inflate(requireActivity().layoutInflater)
        dialogBuilder.setView(binding.root)
        val arg = arguments
        if (arg != null) {
            binding.tvTotalCost.text = "$"+arg.getInt("KEY1",0).toString()
        }

        dialogBuilder.setPositiveButton("OK") { dialog, which ->
        }
        return dialogBuilder.create()

    }
}