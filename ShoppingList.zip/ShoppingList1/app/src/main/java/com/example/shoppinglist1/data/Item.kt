package com.example.shoppinglist1.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "itemtable")
data class Item(
    @PrimaryKey(autoGenerate = true) val itemid: Long?,
    @ColumnInfo(name = "isBought") var isBought: Boolean,
    @ColumnInfo(name = "itemName") var itemName: String,
    @ColumnInfo(name = "itemCategory") var itemCategory: Int,
    @ColumnInfo(name = "itemPrice") var itemPrice: String,
    @ColumnInfo(name = "itemDescription") var itemDescription: String,
): Serializable