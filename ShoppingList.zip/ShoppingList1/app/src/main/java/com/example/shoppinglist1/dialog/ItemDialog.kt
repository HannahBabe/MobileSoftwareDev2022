package com.example.shoppinglist1.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.shoppinglist1.R
import com.example.shoppinglist1.ScrollingActivity
import com.example.shoppinglist1.data.Item
import com.example.shoppinglist1.databinding.ItemDialogBinding
import java.util.*


class ItemDialog : DialogFragment() {

    interface ItemHandler{
        fun itemCreated(item: Item)

        fun itemUpdated(item: Item)
    }

    lateinit var itemHandler: ItemHandler

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is ItemHandler){
            itemHandler = context
        } else {
            throw RuntimeException(
                "The Activity is not implementing the TodoHandler interface.")
        }
    }

    lateinit var binding: ItemDialogBinding

    private var isEditMode = false

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())

        //are we in edit mode?  - have we received a Todo object to edit?
        if (arguments != null && requireArguments().containsKey(
                ScrollingActivity.KEY_ITEM_EDIT)) {
            isEditMode = true
            dialogBuilder.setTitle(getString(R.string.edit_item))
        } else {
            isEditMode = false
            dialogBuilder.setTitle(getString(R.string.new_item))
        }

        binding = ItemDialogBinding.inflate(requireActivity().layoutInflater)
        dialogBuilder.setView(binding.root)

        val categoriesAdapter = ArrayAdapter.createFromResource(
            requireActivity(),//not sure if this is correct
            R.array.categories,
            android.R.layout.simple_spinner_item,
        )
        categoriesAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        binding.spCategory.adapter = categoriesAdapter

        //pre-fill the dialog if we are in edit mode
        if (isEditMode) {
            val itemToEdit =
                requireArguments().getSerializable(
                    ScrollingActivity.KEY_ITEM_EDIT) as Item

            //Get selected spinner index
            val adapter = ArrayAdapter.createFromResource(
                requireActivity(),
                R.array.categories,
                android.R.layout.simple_spinner_item
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spCategory.setAdapter(adapter)
            binding.spCategory.setSelection(itemToEdit.itemCategory)

            binding.etItemName.setText(itemToEdit.itemName)
            binding.etItemDescription.setText(itemToEdit.itemDescription)
            binding.etItemPrice.setText(itemToEdit.itemPrice)
            binding.cbItemBought.isChecked = itemToEdit.isBought
        }

        dialogBuilder.setPositiveButton(getString(R.string.ok)) { dialog, which ->
        }

        dialogBuilder.setNegativeButton(getString(R.string.cancel)) { dialog, which ->
        }

        return dialogBuilder.create()
    }

    override fun onResume() {
        super.onResume()

        val dialog = dialog as AlertDialog
        val positiveButton = dialog.getButton(Dialog.BUTTON_POSITIVE)

        positiveButton.setOnClickListener {
            if (binding.etItemName.text.isEmpty()) {
                binding.etItemName.error = getString(R.string.empty_field_error)
            } else {
                if (isEditMode) {
                    handleEdit()
                } else {
                    handleCreate()
                }

                dialog.dismiss()
            }
        }

    }

    private fun handleCreate() {
        itemHandler.itemCreated(
            Item(
                null,
                binding.cbItemBought.isChecked,
                binding.etItemName.text.toString(),
                binding.spCategory.selectedItemPosition,
                binding.etItemPrice.text.toString(),
                binding.etItemDescription.text.toString(),
            )
        )
    }

    private fun handleEdit() {
        val itemToEdit =
            (requireArguments().getSerializable(
                ScrollingActivity.KEY_ITEM_EDIT
            ) as Item).copy( //Need to make a copy of the item in order for the recycler view to recognize that a change was made.
                itemName = binding.etItemName.text.toString(),
                itemDescription = binding.etItemDescription.text.toString(),
                itemPrice = binding.etItemPrice.text.toString(),
                itemCategory = binding.spCategory.selectedItemPosition,//change to selectedItemPosition, and setSelectedIndex
                isBought = binding.cbItemBought.isChecked
            )

        itemHandler.itemUpdated(itemToEdit)
    }

}