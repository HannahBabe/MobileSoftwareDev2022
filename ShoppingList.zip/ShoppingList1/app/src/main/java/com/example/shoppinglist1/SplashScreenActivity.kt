package com.example.shoppinglist1

import android.content.Intent
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.example.shoppinglist1.databinding.SplashScreenBinding


class SplashScreenActivity : AppCompatActivity() {

    lateinit var binding: SplashScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val anim = AnimationUtils.loadAnimation(this, R.anim.splash_anim)

        binding.ivList.startAnimation(anim)

        anim.setAnimationListener(
            object: Animation.AnimationListener {
                override fun onAnimationStart(p0: Animation?) {
                }

                override fun onAnimationEnd(p0: Animation?) {
                    startActivity(Intent(this@SplashScreenActivity, ScrollingActivity::class.java))
                    finish()
                }

                override fun onAnimationRepeat(p0: Animation?) {
                }
            }
        )


    }
}