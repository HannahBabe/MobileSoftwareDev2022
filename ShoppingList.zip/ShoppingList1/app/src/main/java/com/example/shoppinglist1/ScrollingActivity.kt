package com.example.shoppinglist1

import android.os.Bundle
import android.util.Log
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.ItemTouchHelper
import com.example.shoppinglist1.adapter.ItemAdapter
import com.example.shoppinglist1.data.AppDatabase
import com.example.shoppinglist1.data.Item
import com.example.shoppinglist1.databinding.ActivityScrollingBinding
import com.example.shoppinglist1.dialog.ItemDialog
import com.example.shoppinglist1.dialog.SummaryDialog
import com.example.shoppinglist1.touch.ItemRecyclerTouchCallback
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetPrompt
import kotlin.concurrent.thread

class ScrollingActivity : AppCompatActivity(), ItemDialog.ItemHandler {

    companion object{
        const val KEY_ITEM_EDIT = "KEY_ITEM_EDIT"
        const val PREFNAME = "MYPREFERENCES"
        const val KEY_WAS_STARTED = "KEY_WAS_STARTED"
    }

    private lateinit var binding: ActivityScrollingBinding
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityScrollingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(findViewById(R.id.toolbar))
        binding.toolbarLayout.title = title
        binding.fab.setOnClickListener { view ->
            ItemDialog().show(supportFragmentManager, "TODO_DIALOG")
        }

        binding.btnDeleteAll.setOnClickListener{
            thread {
                AppDatabase.getInstance(this@ScrollingActivity).itemDao().deleteAll()
            }
        }

        binding.btnSummary.setOnClickListener{view ->
            var totalPrice = 0
            thread {
                val allItemPrices =
                    AppDatabase.getInstance(this@ScrollingActivity).itemDao().getAllPrices()
                allItemPrices.forEach{itemPrice ->
                    totalPrice += itemPrice.toInt()
                }

                val dialog = SummaryDialog()
                val bundle = Bundle()
                bundle.putInt("KEY1",totalPrice)
                dialog.arguments = bundle
                dialog.show(supportFragmentManager, "SUMMARY_DIALOG")
            }

        }

        initRecyclerView()

        if(!wasStartedBefore()) {
            MaterialTapTargetPrompt.Builder(this)
                .setTarget(binding.fab)
                .setPrimaryText(getString(R.string.new_item))
                .setSecondaryText(getString(R.string.click_to_add_new_item))
                .show()
            saveAppWasStarted()
        }
    }


    private fun saveAppWasStarted() {
        val sharedpref = getSharedPreferences(PREFNAME,
            MODE_PRIVATE)
        val editor = sharedpref.edit()
        editor.putBoolean(KEY_WAS_STARTED, true)
        editor.apply()
    }

    private fun wasStartedBefore() : Boolean {
        val sharedPref = getSharedPreferences(PREFNAME, MODE_PRIVATE)
        return sharedPref.getBoolean(KEY_WAS_STARTED, false)
    }

    private fun initRecyclerView() {
        adapter = ItemAdapter(this)
        binding.recyclerItem.adapter = adapter

        val touchCallbakList = ItemRecyclerTouchCallback(adapter)
        val itemTouchHelper = ItemTouchHelper(touchCallbakList)
        itemTouchHelper.attachToRecyclerView(binding.recyclerItem)

        val todoItems = AppDatabase.getInstance(this).itemDao().getAllItems()
        todoItems.observe(this, Observer { items ->
            adapter.submitList(items)
        })
    }

    fun showEditDialog(itemToEdit: Item){
        val dialog = ItemDialog()

        val bundle = Bundle()
        bundle.putSerializable(KEY_ITEM_EDIT, itemToEdit)
        dialog.arguments = bundle
        dialog.show(supportFragmentManager, "TAG_ITEM_EDIT")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun itemCreated(item: Item) {
        thread {
            AppDatabase.getInstance(this).itemDao().insertItem(item)
            runOnUiThread {

                Snackbar.make(binding.root, getString(R.string.item_created), Snackbar.LENGTH_LONG)
                    .setAction(getString(R.string.undo)) {
                        adapter.deleteLastItem()
                    }
                    .show()
            }
        }
    }

    override fun itemUpdated(item: Item) {
        thread{
            AppDatabase.getInstance(this).itemDao().updateItem(item)
        }
    }
}